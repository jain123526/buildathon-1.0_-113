"""
CWC Scraper Module

Handles web scraping of CWC reservoir data from official sources.
"""

import requests
from bs4 import BeautifulSoup
import logging
from typing import List, Dict
from datetime import datetime

from .constants import CWC_RESERVOIR_URL, HTTP_HEADERS, REQUEST_TIMEOUT
from .sample_data import get_sample_data

logger = logging.getLogger(__name__)


def fetch_cwc_reservoir_data() -> List[Dict]:
    """
    Fetch reservoir data from CWC website
    
    Returns:
        List of dictionaries containing reservoir data
    """
    try:
        logger.info(f"Fetching data from CWC: {CWC_RESERVOIR_URL}")
        
        response = requests.get(
            CWC_RESERVOIR_URL, 
            headers=HTTP_HEADERS, 
            timeout=REQUEST_TIMEOUT
        )
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Find the main data table
        table = soup.find('table')
        if not table:
            logger.warning("No table found in CWC data, using sample data")
            return get_sample_data()
        
        rows = table.find_all('tr')
        data = []
        
        for row in rows[1:]:  # Skip header row
            cols = row.find_all('td')
            if len(cols) >= 5:
                try:
                    site = cols[0].text.strip()
                    level = float(cols[1].text.strip()) if cols[1].text.strip() else 0.0
                    discharge = float(cols[2].text.strip()) if cols[2].text.strip() else 0.0
                    flow = float(cols[3].text.strip()) if cols[3].text.strip() else 0.0
                    turbulence = float(cols[4].text.strip()) if cols[4].text.strip() else 0.0
                    
                    data.append({
                        "site": site,
                        "level": level,
                        "discharge": discharge,
                        "flow": flow,
                        "turbulence": turbulence,
                        "timestamp": datetime.now().isoformat()
                    })
                except (ValueError, IndexError) as e:
                    logger.warning(f"Error parsing row: {e}")
                    continue
        
        if data:
            logger.info(f"Successfully fetched {len(data)} reservoir data points")
            return data
        else:
            logger.warning("No valid data found, using sample data")
            return get_sample_data()
            
    except requests.RequestException as e:
        logger.error(f"Error fetching CWC data: {e}")
        logger.info("Using sample data as fallback")
        return get_sample_data()
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return get_sample_data()
