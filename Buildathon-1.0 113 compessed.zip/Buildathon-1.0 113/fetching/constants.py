"""
Constants Module for CWC Data Fetcher

Contains all configuration constants, URLs, and settings.
"""

# API and Data Source URLs
INDIA_WRIS_API = "https://indiawris.gov.in/wris/#/RiverMonitoring"
CWC_RESERVOIR_URL = "https://cwc.gov.in/sites/default/files/realtimereservoirdata.html"

# HTTP Configuration
HTTP_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}

# Request Timeout (seconds)
REQUEST_TIMEOUT = 10

# Logging Configuration
LOG_LEVEL = 'INFO'
