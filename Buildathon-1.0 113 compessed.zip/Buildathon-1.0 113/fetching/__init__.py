"""
Fetching Package for CWC Data

This package provides modules for fetching water level data from
Central Water Commission (CWC) and India WRIS sources.
"""

__version__ = '1.0.0'
__author__ = 'AquaVision AI Team'

# Import main functions for backward compatibility
from .fetcher import fetch_cwc_data, get_latest_reading

__all__ = ['fetch_cwc_data', 'get_latest_reading']
