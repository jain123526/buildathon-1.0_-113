"""
Main Fetcher Module

Orchestrates data fetching from multiple sources with fallback logic.
"""

import logging
from typing import List, Dict, Optional

from .cwc_scraper import fetch_cwc_reservoir_data
from .sample_data import get_sample_data

logger = logging.getLogger(__name__)


def fetch_cwc_data() -> List[Dict]:
    """
    Main function to fetch CWC water data
    Tries multiple sources and returns the best available data
    
    Returns:
        List of dictionaries containing water level data
    """
    # Try CWC reservoir data first
    data = fetch_cwc_reservoir_data()
    
    if data:
        logger.info(f"Returning {len(data)} data points")
        return data
    
    # Fallback to sample data
    logger.warning("All sources failed, returning sample data")
    return get_sample_data()


def get_latest_reading(site_name: Optional[str] = None) -> Optional[Dict]:
    """
    Get the latest reading for a specific site or the first available site
    
    Args:
        site_name: Optional site name to filter by
        
    Returns:
        Dictionary with latest reading or None
    """
    data = fetch_cwc_data()
    
    if not data:
        return None
    
    if site_name:
        for reading in data:
            if reading.get('site', '').lower() == site_name.lower():
                return reading
        return None
    
    return data[0] if data else None
