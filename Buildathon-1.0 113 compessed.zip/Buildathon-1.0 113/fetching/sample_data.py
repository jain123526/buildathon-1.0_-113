"""
Sample Data Module for CWC Data Fetcher

Provides sample/fallback data when live sources are unavailable.
"""

from datetime import datetime
from typing import List, Dict


# Sample CWC data based on real reservoir format
SAMPLE_CWC_DATA = [
    {
        "site": "Tehri Dam",
        "river": "Bhagirathi",
        "state": "Uttarakhand",
        "level": 830.5,
        "discharge": 150.3,
        "flow": 2.8,
        "turbulence": 0.45,
        "capacity": 85.2,
        "timestamp": datetime.now().isoformat()
    },
    {
        "site": "Bhakra Dam",
        "river": "Sutlej",
        "state": "Himachal Pradesh",
        "level": 512.3,
        "discharge": 220.7,
        "flow": 3.2,
        "turbulence": 0.52,
        "capacity": 92.1,
        "timestamp": datetime.now().isoformat()
    },
    {
        "site": "Sardar Sarovar Dam",
        "river": "Narmada",
        "state": "Gujarat",
        "level": 138.2,
        "discharge": 180.5,
        "flow": 2.5,
        "turbulence": 0.38,
        "capacity": 78.5,
        "timestamp": datetime.now().isoformat()
    }
]


def get_sample_data() -> List[Dict]:
    """
    Get sample CWC data with current timestamps
    
    Returns:
        List of dictionaries containing sample water level data
    """
    # Update timestamps to current time
    current_time = datetime.now().isoformat()
    data = []
    
    for item in SAMPLE_CWC_DATA:
        updated_item = item.copy()
        updated_item['timestamp'] = current_time
        data.append(updated_item)
    
    return data
