"""
AquaVision AI Backend - Main Entry Point

Simplified entry point that imports and runs the Flask application.
"""

import logging
from backend.app import app
from backend.config import FLASK_HOST, FLASK_PORT, FLASK_DEBUG, FLASK_THREADED
from backend.config import INFLUX_HOST, INFLUX_PORT, INFLUX_DATABASE

logger = logging.getLogger(__name__)

if __name__ == '__main__':
    logger.info("Starting AquaVision AI Backend Server...")
    logger.info(f"InfluxDB: {INFLUX_HOST}:{INFLUX_PORT}/{INFLUX_DATABASE}")
    
    # Run the Flask app
    app.run(
        host=FLASK_HOST,
        port=FLASK_PORT,
        debug=FLASK_DEBUG,
        threaded=FLASK_THREADED
    )
