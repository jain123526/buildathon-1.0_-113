"""
CWC Data Fetcher Module - Backward Compatibility Wrapper

This module provides backward compatibility by importing from the new modular structure.
For new code, import directly from the fetching package:
    from fetching import fetch_cwc_data, get_latest_reading
"""

import logging

# Import from the new modular structure
from fetching.fetcher import fetch_cwc_data, get_latest_reading
from fetching.constants import INDIA_WRIS_API, CWC_RESERVOIR_URL
from fetching.sample_data import SAMPLE_CWC_DATA

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Export all functions for backward compatibility
__all__ = [
    'fetch_cwc_data',
    'get_latest_reading',
    'INDIA_WRIS_API',
    'CWC_RESERVOIR_URL',
    'SAMPLE_CWC_DATA'
]


if __name__ == "__main__":
    # Test the fetcher
    print("Testing CWC Data Fetcher...")
    data = fetch_cwc_data()
    print(f"\nFetched {len(data)} data points:")
    for item in data:
        print(f"  - {item['site']}: Level={item['level']}m, Discharge={item['discharge']}m³/s")
