"""
Database Module for AquaVision AI Backend

Handles InfluxDB client initialization and database operations.
"""

import logging
from influxdb import InfluxDBClient
from influxdb.exceptions import InfluxDBClientError
from typing import Optional

from .config import INFLUX_HOST, INFLUX_PORT, INFLUX_DATABASE

logger = logging.getLogger(__name__)


class DatabaseManager:
    """Manages InfluxDB connection and operations"""
    
    def __init__(self, host: str = INFLUX_HOST, port: int = INFLUX_PORT, 
                 database: str = INFLUX_DATABASE):
        """
        Initialize database manager
        
        Args:
            host: InfluxDB host address
            port: InfluxDB port number
            database: Database name
        """
        self.host = host
        self.port = port
        self.database = database
        self.client: Optional[InfluxDBClient] = None
        self._connect()
    
    def _connect(self):
        """Establish connection to InfluxDB"""
        try:
            self.client = InfluxDBClient(host=self.host, port=self.port)
            self.client.switch_database(self.database)
            logger.info(f"Connected to InfluxDB at {self.host}:{self.port}/{self.database}")
        except Exception as e:
            logger.error(f"Failed to connect to InfluxDB: {e}")
            self.client = None
    
    def is_connected(self) -> bool:
        """Check if database is connected"""
        if not self.client:
            return False
        try:
            self.client.ping()
            return True
        except Exception:
            return False
    
    def query(self, query_string: str):
        """
        Execute a query on InfluxDB
        
        Args:
            query_string: InfluxQL query string
            
        Returns:
            Query result
            
        Raises:
            InfluxDBClientError: If query fails
        """
        if not self.client:
            raise InfluxDBClientError("Database not connected")
        
        logger.info(f"Executing query: {query_string}")
        return self.client.query(query_string)
    
    def get_latest(self, limit: int = 1, site: Optional[str] = None):
        """
        Get latest readings from database
        
        Args:
            limit: Number of records to return
            site: Optional site filter
            
        Returns:
            List of data points
        """
        query = f"SELECT * FROM river"
        if site:
            query += f" WHERE site='{site}'"
        query += f" ORDER BY time DESC LIMIT {limit}"
        
        result = self.query(query)
        return list(result.get_points())
    
    def get_history(self, hours: int = 24, site: Optional[str] = None):
        """
        Get historical data
        
        Args:
            hours: Number of hours of history
            site: Optional site filter
            
        Returns:
            List of data points
        """
        query = f"SELECT * FROM river WHERE time > now() - {hours}h"
        if site:
            query += f" AND site='{site}'"
        query += " ORDER BY time ASC"
        
        result = self.query(query)
        return list(result.get_points())
    
    def get_sites(self):
        """
        Get list of all monitoring sites
        
        Returns:
            List of site names
        """
        query = "SHOW TAG VALUES FROM river WITH KEY = site"
        result = self.query(query)
        return [point['value'] for point in result.get_points()]
    
    def close(self):
        """Close database connection"""
        if self.client:
            self.client.close()
            logger.info("InfluxDB connection closed")


# Global database instance
db_manager: Optional[DatabaseManager] = None


def get_db() -> DatabaseManager:
    """
    Get or create database manager instance
    
    Returns:
        DatabaseManager instance
    """
    global db_manager
    if db_manager is None:
        db_manager = DatabaseManager()
    return db_manager
