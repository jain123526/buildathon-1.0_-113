"""
Routes Module for AquaVision AI Backend

Defines all API endpoints for the Flask application.
"""

import logging
from flask import Blueprint, jsonify, request
from datetime import datetime
from influxdb.exceptions import InfluxDBClientError

from .database import get_db

logger = logging.getLogger(__name__)

# Create Blueprint for API routes
api = Blueprint('api', __name__)


# Import custom modules with error handling
try:
    from fetching import fetch_cwc_data
except ImportError:
    fetch_cwc_data = None
    logger.warning("fetching module not available")
    
try:
    from inserting import InfluxDBHandler
except ImportError:
    InfluxDBHandler = None
    logger.warning("inserting module not available")


@api.route('/', methods=['GET'])
def index():
    """Health check endpoint"""
    return jsonify({
        'status': 'running',
        'service': 'AquaVision AI Backend',
        'version': '1.0.0',
        'timestamp': datetime.utcnow().isoformat()
    })


@api.route('/health', methods=['GET'])
def health():
    """Detailed health check with service status"""
    health_status = {
        'api': 'healthy',
        'influxdb': 'unknown',
        'fetcher': 'available' if fetch_cwc_data else 'unavailable',
        'timestamp': datetime.utcnow().isoformat()
    }
    
    # Check InfluxDB connection
    db = get_db()
    if db.is_connected():
        health_status['influxdb'] = 'healthy'
    else:
        health_status['influxdb'] = 'unhealthy'
        logger.error("InfluxDB health check failed")
    
    status_code = 200 if health_status['influxdb'] == 'healthy' else 503
    return jsonify(health_status), status_code


@api.route('/update', methods=['GET', 'POST'])
def update():
    """
    Fetch latest water data and store to InfluxDB
    
    Returns:
        JSON response with status and data count
    """
    if not fetch_cwc_data:
        return jsonify({
            'error': 'Fetcher module not available',
            'message': 'Please ensure fetching.py is properly configured'
        }), 500
    
    if not InfluxDBHandler:
        return jsonify({
            'error': 'Database handler not available',
            'message': 'Please ensure inserting.py is properly configured'
        }), 500
    
    try:
        # Fetch data from CWC
        logger.info("Fetching water data from CWC...")
        data = fetch_cwc_data()
        
        if not data:
            return jsonify({
                'status': 'warning',
                'message': 'No data fetched from source',
                'count': 0
            }), 200
        
        # Store to InfluxDB
        logger.info(f"Storing {len(data)} data points to InfluxDB...")
        from .config import INFLUX_HOST, INFLUX_PORT, INFLUX_DATABASE
        
        handler = InfluxDBHandler(
            host=INFLUX_HOST,
            port=INFLUX_PORT,
            database=INFLUX_DATABASE
        )
        
        success = handler.store_to_influx(data)
        handler.close()
        
        if success:
            return jsonify({
                'status': 'success',
                'message': 'Data stored successfully',
                'count': len(data),
                'timestamp': datetime.utcnow().isoformat()
            }), 200
        else:
            return jsonify({
                'status': 'error',
                'message': 'Failed to store data to InfluxDB',
                'count': 0
            }), 500
            
    except Exception as e:
        logger.error(f"Error in update endpoint: {e}")
        return jsonify({
            'error': 'Internal server error',
            'message': str(e)
        }), 500


@api.route('/latest', methods=['GET'])
def latest():
    """
    Get the latest water level reading from InfluxDB
    
    Query Parameters:
        limit (int): Number of records to return (default: 1)
        site (str): Filter by specific site
    
    Returns:
        JSON response with latest data points
    """
    db = get_db()
    if not db.is_connected():
        return jsonify({
            'error': 'Database not available',
            'message': 'InfluxDB connection not established'
        }), 500
    
    try:
        # Get query parameters
        limit = request.args.get('limit', default=1, type=int)
        site = request.args.get('site', default=None, type=str)
        
        # Query database
        points = db.get_latest(limit=limit, site=site)
        
        if not points:
            return jsonify({
                'status': 'success',
                'message': 'No data available',
                'data': [],
                'count': 0
            }), 200
        
        return jsonify({
            'status': 'success',
            'data': points,
            'count': len(points),
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except InfluxDBClientError as e:
        logger.error(f"InfluxDB query error: {e}")
        return jsonify({
            'error': 'Database query failed',
            'message': str(e)
        }), 500
    except Exception as e:
        logger.error(f"Error in latest endpoint: {e}")
        return jsonify({
            'error': 'Internal server error',
            'message': str(e)
        }), 500


@api.route('/history', methods=['GET'])
def history():
    """
    Get historical water level data
    
    Query Parameters:
        hours (int): Number of hours of history (default: 24)
        site (str): Filter by specific site
    
    Returns:
        JSON response with historical data points
    """
    db = get_db()
    if not db.is_connected():
        return jsonify({
            'error': 'Database not available',
            'message': 'InfluxDB connection not established'
        }), 500
    
    try:
        # Get query parameters
        hours = request.args.get('hours', default=24, type=int)
        site = request.args.get('site', default=None, type=str)
        
        # Query database
        points = db.get_history(hours=hours, site=site)
        
        return jsonify({
            'status': 'success',
            'data': points,
            'count': len(points),
            'hours': hours,
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except InfluxDBClientError as e:
        logger.error(f"InfluxDB query error: {e}")
        return jsonify({
            'error': 'Database query failed',
            'message': str(e)
        }), 500
    except Exception as e:
        logger.error(f"Error in history endpoint: {e}")
        return jsonify({
            'error': 'Internal server error',
            'message': str(e)
        }), 500


@api.route('/cwc/realtime', methods=['GET'])
def cwc_realtime():
    """
    Get real-time CWC water data directly from the fetcher
    
    Query Parameters:
        site (str): Filter by specific site name
    
    Returns:
        JSON response with real-time CWC data
    """
    if not fetch_cwc_data:
        return jsonify({
            'error': 'Fetcher not available',
            'message': 'CWC data fetcher module not loaded'
        }), 500
    
    try:
        site_filter = request.args.get('site', default=None, type=str)
        
        logger.info("Fetching real-time CWC data...")
        data = fetch_cwc_data()
        
        if not data:
            return jsonify({
                'status': 'success',
                'message': 'No data available from CWC',
                'data': [],
                'count': 0,
                'source': 'CWC',
                'timestamp': datetime.utcnow().isoformat()
            }), 200
        
        # Filter by site if requested
        if site_filter:
            data = [d for d in data if d.get('site', '').lower() == site_filter.lower()]
        
        return jsonify({
            'status': 'success',
            'data': data,
            'count': len(data),
            'source': 'CWC',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Error in cwc/realtime endpoint: {e}")
        return jsonify({
            'error': 'Internal server error',
            'message': str(e)
        }), 500


@api.route('/sites', methods=['GET'])
def sites():
    """
    Get list of all monitoring sites
    
    Returns:
        JSON response with list of sites
    """
    db = get_db()
    if not db.is_connected():
        return jsonify({
            'error': 'Database not available',
            'message': 'InfluxDB connection not established'
        }), 500
    
    try:
        sites_list = db.get_sites()
        
        return jsonify({
            'status': 'success',
            'sites': sites_list,
            'count': len(sites_list),
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Error in sites endpoint: {e}")
        return jsonify({
            'error': 'Internal server error',
            'message': str(e)
        }), 500
