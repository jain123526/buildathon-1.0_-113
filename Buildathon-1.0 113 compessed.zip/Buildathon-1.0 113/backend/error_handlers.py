"""
Error Handlers Module for AquaVision AI Backend

Defines custom error handlers for the Flask application.
"""

import logging
from flask import jsonify

logger = logging.getLogger(__name__)


def register_error_handlers(app):
    """
    Register error handlers with the Flask app
    
    Args:
        app: Flask application instance
    """
    
    @app.errorhandler(404)
    def not_found(error):
        """Handle 404 errors"""
        return jsonify({
            'error': 'Not found',
            'message': 'The requested endpoint does not exist'
        }), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        """Handle 500 errors"""
        logger.error(f"Internal server error: {error}")
        return jsonify({
            'error': 'Internal server error',
            'message': 'An unexpected error occurred'
        }), 500
    
    @app.errorhandler(400)
    def bad_request(error):
        """Handle 400 errors"""
        return jsonify({
            'error': 'Bad request',
            'message': 'The request was invalid or malformed'
        }), 400
    
    @app.errorhandler(503)
    def service_unavailable(error):
        """Handle 503 errors"""
        return jsonify({
            'error': 'Service unavailable',
            'message': 'The service is temporarily unavailable'
        }), 503
