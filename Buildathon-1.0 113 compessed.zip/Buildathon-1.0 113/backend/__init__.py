"""
AquaVision AI Backend Package

This package provides the Flask backend API for water monitoring data.
"""

__version__ = '1.0.0'
__author__ = 'AquaVision AI Team'
