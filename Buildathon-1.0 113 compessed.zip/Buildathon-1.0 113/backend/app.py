"""
Flask Application Factory for AquaVision AI Backend

Creates and configures the Flask application instance.
"""

import logging
from flask import Flask
from flask_cors import CORS

from .config import APP_NAME, APP_VERSION, FLASK_DEBUG, configure_logging
from .routes import api
from .error_handlers import register_error_handlers

logger = logging.getLogger(__name__)


def create_app():
    """
    Create and configure Flask application
    
    Returns:
        Flask application instance
    """
    # Configure logging
    configure_logging()
    
    # Create Flask app
    app = Flask(__name__)
    
    # Enable CORS for frontend integration
    CORS(app)
    
    # Register blueprints
    app.register_blueprint(api)
    
    # Register error handlers
    register_error_handlers(app)
    
    logger.info(f"Initialized {APP_NAME} v{APP_VERSION}")
    logger.info(f"Debug mode: {FLASK_DEBUG}")
    
    return app


# Create app instance
app = create_app()
