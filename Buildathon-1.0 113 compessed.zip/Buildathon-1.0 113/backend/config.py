"""
Configuration Module for AquaVision AI Backend

Contains all configuration settings and constants for the application.
"""

import logging

# InfluxDB Configuration
INFLUX_HOST = 'localhost'
INFLUX_PORT = 8086
INFLUX_DATABASE = 'river_data'

# Flask Configuration
FLASK_HOST = '0.0.0.0'
FLASK_PORT = 5000
FLASK_DEBUG = True
FLASK_THREADED = True

# Application Information
APP_NAME = 'AquaVision AI Backend'
APP_VERSION = '1.0.0'

# Logging Configuration
LOG_LEVEL = logging.INFO
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'


def configure_logging():
    """Configure application logging"""
    logging.basicConfig(
        level=LOG_LEVEL,
        format=LOG_FORMAT
    )
    return logging.getLogger(__name__)


# Initialize logger
logger = configure_logging()
